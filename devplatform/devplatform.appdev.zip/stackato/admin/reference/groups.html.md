---
layout: default-devplatform
permalink: /als/v1/admin/reference/groups/
---
<!--PUBLISHED-->

Managing Groups, Users & Limits (DEPRECATED)[](#managing-groups-users-limits-deprecated "Permalink to this headline")
===================================================================================================================

##* Warning *

Application Lifecycle Service Groups have been **replaced** by [*Organizations and
Spaces*](/als/v1/user/deploy/orgs-spaces/#orgs-spaces).