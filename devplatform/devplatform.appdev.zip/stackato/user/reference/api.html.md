---
layout: default-devplatform
permalink: /als/v1/user/reference/api/
---
<!--PUBLISHED-->

Application Lifecycle Service Client API[](#helion-client-api "Permalink to this headline")
=========================================================================

Application Lifecycle Service is fully compatible with the [Cloud Foundry v2
API](/als/v1/user/reference/api/).

