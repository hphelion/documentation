---
layout: default
title: "HP Helion OpenStack&reg; Open Source and Third-Party Software License Agreements"
permalink: /helion/openstack/3rd-party-license-agreements/
product: commercial.ga

---
<!--PUBLISHED-->

<script> 

function PageRefresh { 
onLoad="window.refresh"
}

PageRefresh();

</script>

<!--
<p style="font-size: small;"> <a href="/helion/openstack/eula/">&#9664; PREV | <a href="/helion/openstack/">&#9650; UP</a> | <a href="/helion/openstack/siteindex/">NEXT &#9654;</a> </p>
-->

<h1 id="hp-helion-openstack-beta-open-source-and-third-party-software-license-agreements">HP Helion OpenStack&reg; Open Source and Third-Party Software License Agreements</h1>

The Open Source and Third-Party Software License Agreements for HP Helion OpenStack are available as a PDF download.

<a href="http://g4ab5833062539391ca85f3382e39498a.cdn.hpcloudsvc.com/3rd-Party-OS-Licenses/HP_Helion_OpenStack_OS_and_3rd_Party_Software_License_Agreements.pdf">Download the PDF document.</a>


<p style="font-size: small;"> <a href="/helion/"> &#171; Return to HP Helion  home </a> </p>




