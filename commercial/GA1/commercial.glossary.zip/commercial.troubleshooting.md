---
layout: default
title: "HP Helion OpenStack&#174; Orchestration High Availability Service Overview"
permalink: /helion/openstack/services/troubleshooting/
product: commercial.ga

---
<!--PUBLISHED-->

<script>

function PageRefresh {
onLoad="window.refresh"
}

PageRefresh();

</script>
<!--

<p style="font-size: small;"> <a href="/helion/openstack/services/object/overview/">&#9664; PREV</a> | <a href="/helion/openstack/services/overview/">&#9650; UP</a> | <a href="/helion/openstack/services/reporting/overview/"> NEXT &#9654</a> </p> --->


# HP Helion OpenStack&#174;  Troubleshooting

HP Helion OpenStack&#174; is an OpenStack technology coupled with a version of Linux&reg; provided by HP. This topic describes all the known issues that you might encounter. To help you resolve these issues, we have provided possible solutions.

For easy reference, we categorized the known issues and solutions as follows:

* [Baremetal installation](#baremetal-install)
	* [KVM](#kvm)
	* [ESX and OVSvAPP](#esx-ovsvapp)
* [Logging](#logging)
* [VSA](#vsa)


If you need further assistance, contact [HP Customer Support]([http://www.hpcloud.com/about/contact](http://www.hpcloud.com/about/contact)).


## Baremetal installation {#baremetal-install}

###KVM {#kvm}

1. [Fatal PCI Express Device Error](#fatal-pci)
2. [IPMI fails with error- unable to establish IPMI v2 / RMCP+ session](#IPMI-fails)
3. [Failure of Update Overcloud](#failure-overcloud)
4. [Installation failure as the flavor to be used for overcloud nodes does not match](#installation-failure)
5. [PXE boot on target node keeps switching between interfaces](#PXE-boot-on-target)
6. [BIOS blocks are not set to correct date and time across all nodes](#BIOS-blocks-are-not-set-to-correct-date)
7. [iLO console shows hLinux daemon.err tgtd while PXE booting](#ilo-console)
8. [iLO console shows null waiting for notice of completion while PXE booting](#ilo-show-null)
9. [Failure of Hp_ced_installer.sh](#failure-installer)
10. [Failure of Seed Installation](#seed-install-failure)
11. [NovaCompute node fails when installing overcloud](#novacompute-fails)


###Fatal PCI Express Device Error {#fatal-pci}

**System Behavior/Message**

When installing on HP ProLiant SL390s and HP ProLiant BL490d systems, the following error has occasionally occurred:

    `Fatal PCI Express Device Error PCI Slot ?
     B00/D00/F00`


**Resolution**

If you get this error, reset the system that experienced the error:

   1. Connect to the iLO using Internet Explorer:
        `https://<iLO IP address>`
   2. Navigate to Information / Diagnostics.
   3. Reset iLO.
   4. Log back into the iLO after 30 seconds.
   5. Navigate to Remote Console / Remote Console.
   6. Open the integrated remote console (.NET).
   7. Click Power switch / Press and Hold.
   8. Click Power switch / Momentary Press, and wait for the system to restart.

   The system should now boot normally.

* If the overcloud controller is rebooted (due to a power issue, hardware upgrade, or similar event), OpenStack compute tools such as `nova-list` might report that the VMs are in an ERROR state, rendering the overcloud unusable. To restore the overcloud to an operational state, follow the steps below:
 
  1. As user `root` on the overcloud controller you must:
  
        A. Run the `os-refresh-config` scripts:

            # os-refresh-config

        B. Restart the `mysql` service:

            # service mysql restart

        C. Re-run the `os-refresh-config` scripts:

            # os-refresh-config

        D. Restart all Networking Operations (Neutron) services:

            # service neutron-dhcp-agent restart
            # service neutron-l3-agent restart
            # service neutron-metadata-agent restart
            # service neutron-openvswitch-agent restart
            # service neutron-server restart

  2. On each overcloud node, restart the Neutron and Nova services:
  
            $ sudo service neutron-openvswitch-agent restart
            $ sudo service nova-compute restart
            $ sudo service nova-scheduler restart
            $ sudo service nova-conductor restart


* The installer uses IPMI commands to reset nodes and change their power status. Some systems change to a state in which the `Server Power` status as reported by the iLO is stuck in `RESET`. If this occurs, you must physically disconnect the power from the server for 10 seconds. If the problem persists after that, contact HP Support as there might be a defective component in the system.

* On the system on which the installer is run, the seed VM's networking is bridged onto the external LAN. If you remove HP Helion OpenStack, the network bridge persists. To revert the network configuration to its pre-installation state, run the following commands as user root: 

        # ip addr add 192.168.185.131/16 dev eth0 scope global
        # ip addr del 192.168.185.131/16 dev brbm
        # ovs-vsctl del-port NIC

     where
       * eth0 is the external interface     
       * 192.168.185.131 is the IP address on the external interface - you should replace this with your own IP address.
       * The baremetal bridge is always called 'brbm'

* Before you install the HP Helion OpenStack DNSaaS or if you want to use Heat with HP Helion OpenStack, you **must** modify the /etc/heat/heat.conf file on the overcloud controller as follows.

    **Important**: The installation of the HP Helion OpenStack DNSaaS fails if you do not make these modifications.

    1. Make sure the IP address in the following settings reflects the IP address of the overcloud controller, for example:
    
            heat_metadata_server_url = http://192.0.202.2:8000
            heat_waitcondition_server_url = http://192.0.202.2:8000/v1/waitcondition
            heat_watch_server_url = http://192.0.202.2:8003

        **Note**: You must have admin ssh access to the overcloud controller.

    2. Save the file.
    3. Restart the Heat-related services &ndash; heat-api, heat-api-cfn, heat-api-cloudwatch, and heat-engine.

    4. Ensure there are no Heat resources in an error state, and then delete any stale or corrupted Heat-related stacks.
<br><br>
<hr>


###IPMI fails with an error- unable to establish IPMI v2 / RMCP+ session {#IPMI-fails}

**System Behavior/Message**

When installing on HP ProLiant BL490c systems, the following error has occasionally occurred:


    unable to establish IPMI v2 / RMCP+ session

**Resolution**

If you get this error, perform the following steps:

1. Ensure that the iLO user has administrator privileges, which is required by the IPMITOOL.
2. To check from the iLO remote console, reboot the server and press **F8** to get to ILO Management screen.
3. Click **User** in the menu-bar and select **Edit**. Edit User pop-up box displays .
4. If you are using a BL server in the QA C7000 enclosure, select the **cdl** user to edit.
5. Use &darr;(down arrow key) to select **Administer User Accounts**. 
6. Use the space bar to set the value to **YES**.
7. Select **F10** to save.
8. Click **File** and select **Exit** to close.
<br><br>
<hr>


### Failure of Update Overcloud {#failure-overcloud}

**System Behavior/Message**

Update Overcloud fails with the following error:

 `  Inconsistency between heat description ($OVERCLOUD_NODES) and overcloud configuration ($OVERCLOUD_INSTANCES)`

**Resolution**

If you get this error, perform the below steps:

 1. Log in to Seed.
 
		# ssh root@<Seed IP address>

2.Edit `/root/tripleo/ce_env.json `and update the right variable for build&#95;number and installed&#95;build&#95;number.

The ce&#95;env&#95;json will be displayed as the sample below.

		  "host-ip": "192.168.122.1", 
		   "hp": { 
		     "build_number": 11, 
		     "installed_build_number": 11 

Note that  the build&#95;number is changed from null to the right variable.
 
3.Run the installer script to update the Overcloud. 
 
		# bash -x tripleo/tripleo-incubator/scripts/hp_ced_installer.sh --update-overcloud |& tee update_cloud.log

During the installation, the number of build&#95;number and installed&#95;build&#95;number that you specified are installed.
<br>
<hr>


### Installation failure as the flavor to be used for Overcloud nodes does not match {#installation-failure}

**System Behavior/Message**

If you have a set of Baremetal servers which differ in specifications (e.g. memory and disk), the installation will fail as the flavor to be used for Overcloud nodes does not match with the server that has the lowest specification for memory, disk, and CPU. 

**Probable Cause**

 The 2nd row in `baremetal.csv` which corresponds to the Overcloud Controller node is used to create a flavor for the Overcloud nodes.  

**Resolution**

Edit the **baremetal.csv** file to define the lowest specification server in the second row.
<br><br>
<hr>



####PXE boot on target node keeps switching between interfaces {#PXE-boot-on-target}

**System Behavior/Message**

When node boots up on iLO console it shows node waiting for PXE boot on multiple NICs.


**Probable Cause**

 Multiple NICs are enabled for Network Boot.


**Resolution**

* Reboot the node, using **F9** to get to the BIOS configuration.
* Assuming NIC1(eth0/em1) for the node is connected to a private network shared across node enable it for Network Boot.
* Select System Options > Embedded NICs.
* Set NIC 1 Boot Options = Network Boot.
* Set NIC 2 Boot Options = Disabled.
<br><br>
<hr>

####BIOS blocks are not set to correct date and time across all nodes {#bios-blocks-are-not-set-to-correct-date}


**System Behavior/Message**

Nodes PXE boot but ISCSI does not start.


**Probable Cause**

Time and date across nodes are incorrect.


**Resolution**

Reboot the node, using **F9** to get to the BIOS configuration. BIOS date and time are set correctly and the same on all the systems.

* Select Date and Time.
* Set the Date.
* Set the Time.
* Use the &lt;ENTER> key to accept the new date and time.
* Save the BIOS, which reboots the node again.
* Once the node has rebooted, you can confirm its data and time from the iLO Overview.
<br><br>
<hr>

####iLO console shows hLinux daemon.err tgtd while PXE booting {#ilo-console}

**System Behavior/Message**

PXE boot gets stuck after `daemon.err tgtd`


**Probable Cause**

Node does not have enough disk space


**Resolution**

* Check if target node has disk space mentioned in `baremetal.csv` and is greater than Node_min_disk mentioned in `tripleo/tripleo-incubator/scripts/hp_ced_functions.sh`.
* If disk space is less than Node&#95;min&#95;disk, change Node&#95;min&#95;disk along with DISK&#95;SIZE in `tripleo/tripleo-incubator/scripts/hp_ced_list_nodes.sh` on Seed.
* Re-run the installation script.
<br>
<hr>

####iLO console shows null waiting for notice of completion while PXE booting {#ilo-show-null}

**System Behavior/Message**

Node is powered on and PXE booted but it is powered off after `daemon.err` and stack create fails.

**Probable Cause**

Node does not have enough disk space. SAN boot is enabled for node or local disk is not attached to `/sda`

**Resolution**

Installer expects that SAN boot option is disabled for nodes. Verify whether SAN boot is disabled for BL 490c.

Also, you can boot the targeted BL490c with Ubuntu or any Linux ISO to see what device is shown as the local disk. For the installer it should be `/sda`.

<br>
<hr>

####Failure of Hp&#95;ced_installer.sh {#failure-installer}

**System Behavior/Message**

`Hp_ced_installer.sh` fails because of `baremetal.csv /sda`.


**Resolution**

Verify `baremetal.csv` for empty lines or special characters.
<br><br>
<hr>
####Failure of Seed Installation {#seed-install-failure}


**System Behavior/Message**

Seed installation fails with no space left on device.


**Resolution**

Verify the tripleo directory- user owner and group. It must be **root:root**. Incase it is not set as **root:root** then edit it to root using- `chown root:root tripleo`

<br><br>
<hr>

**System Behavior/Message**

Inconsistent Rabbitmq failure seen on controller nodes while listing queues 

	rabbitmqctl list_queues


**Resolution**

Restart the Rabbitmq service.

<br><br>
<hr>

## ESX and OVSvAPP {#esx-ovsvapp}

1. [nova-manage service list does not list the compute service as running](#nova-compute)
2. [Unable to login to vCenter proxy agent](#unable-login-vcenter)
3. [Unable to backup volumes using Cinder backup](#unable-cinder-backup)
4. [Failure of OVSvAPP deployment](#fails-ovsvapp)


 
###nova-manage service list does not list the compute service as running {#nova-compute}

**System Behavior/Message**

There can be multiple reason why nova-compute service is not listed or has a :) as status.

**Resolution**

To resolve the above issue verify the following:

1.	The ESX Management Network is able to reach the Helion Management Network.
2.	nova-compute service is running (os-svc-restart &#45;n nova-compute).
3.	Verify `/etc/nova/nova-compute.conf` has the right entries.
<br>
<hr>

### Unable to login to vCenter proxy agent {#unable-login-vcenter}

**System Behavior/Message**

 Unable to login to vCenter proxy agent through the console.

**Resolution** 

Users can login to the system using the user `heat-admin ` and the authorized key in the Seed VM.
<br><br>
<hr>

### Unable to backup volumes using Cinder backup {#unable-cinder-backup}

**System Behavior/Message**

 Unable to backup volumes using Cinder backup.

**Resolution**

Cinder-backup is not supported.
<br><br>
<hr>

###Failure of OVSvAPP deployment {#fails-ovsvapp}

**System Behavior/Message**

Failure of OVSvAPP deployment.

**Resolution**

Verify `tripleo/hp-ovsvapp/log/ovs_vapp.log` in the installer directory.

<br><br>
<hr>

**System Behavior/Message**

After reboot of Controller that has the VIP assigned, the hpvcn agent, nova-compute service, nova compute service in the proxy node and HCN agent in OVSvAPP needs to be restarted manually to resume normal operations.

**Resolution**

* To restart nova-compute, execute the following command in compute proxies

		# service nova-compute restart  

* To restart HP VCN agent, execute the following command in OVSvAPP vm's

		#service hpvcn-neutron-agent restart 
<br><br>
<hr>
##VSA {#vsa}

1. [Failure to retrieve netmask from vsa-bridge](#fails-retrieve-netmask)
2. [Installation script detects more than 7 available drive](install-script-detect)
3. [Failure of script due to less than two drives](#failure-script)
4. [Cannot enable AO as only one disk is available](#cannot-enable-ao)
5. [Unable to update the default input json file ](#unable-update-json)
6. [Virtual bridge creation failed for interface <NIC>](#fail-virtual-bridge)
7. [Creation of storage pool failed](#storage-pool-fail)
8. [Failed during post VSA deployment](#post-vsa-fail)
9. [vsa&#95;network cannot be destroyed](#vsa-network)
10. [vsa&#95;storage&#95;pool pool cannot be destroyed](#vsa-pool-cannot-destroy)



###Failure to retrieve netmask from vsa-bridge {#fails-retrieve-netmask}

**System Behavior/Message**
 
Cannot retrieve netmask from interface vsa-bridge

**Probable Cause**

VSA deployment script determines the net-mask and gateway details from the provided interface. When there is no IP address assigned to the VSA bridge, this error may occur.

**Resolution**

To resolve this issue, perform the following steps:

* Check whether the IP address is allocated for the VSA bridge 

* Verify the VSA IP address by using the following command:

  		ifconfig vsa-bridge

<br>
<hr>

###Installation script detects more than 7 available drive {install-script-detect}

**System Behavior/Message**

Maximum supported devices 7.

**Probable Cause**

This issue occurs when there are more than 7 available drives detected by the installation script to deploy StoreVirtual.

**Resolution**

Perform the following steps:

* HP StoreVirtual VSA supports up to 7 disks

* Execute `fdisk &#45;l` and check for number of available drives in the machine other than `/dev/sda`

<br>
<hr>

###Failure of script due to less than two drives {#failure-script}

**System Behavior/Message**

Minimum number of disks must be 2. No disks are available.

**Probable Cause**
When there are less than two drives in the machine, the script will fail to execute.

**Resolution**

To resolve, perform the following steps:

* Execute `fdisk &#45;l`

* Minimum two drives and maximum of 7 drives should be available for the StoreVirtual deployment other than boot disk(`/dev/sda`)

* At least three drives required for enabling AO
<br>
<hr>

### Cannot enable AO as only one disk is available {#cannot-enable-ao}

**Probable Cause**

For Adaptive Optimization to be enabled, at least three drives must be available. `/dev/sdb` must be SSD drive(Tier 0) and the remaining will be Tier 1.

**Resolution**

To resolve the issue, do the following:

* Use RAID controllers to create RAID groups.

* Ensure that you create the RAID group for SSD drives immediately after creating the RAID group for boot volume. For example: If three RAID groups are to be created. The following is recommended :
	
	* **Step 1** : Create the first RAID group for HDD drives and mark this as boot volume(/dev/sda)

	* **Step 2**: Create the second RAID group for SSD drives which should be used as Tier 0 for AO (/dev/sdb)

	* **Step 3**: Create the third RAID group for HDD drives which will be used as Tier 1(/dev/sdc)

<br><hr>


### Unable to update the default input json file {#unable-update-json}

**System Behavior/Message**

Parsing the default JSON file failed. Unable to update the default input json file.

**Probable Cause**

The script will parse the configuration file and update the values based on the network and configuration files.

**Resolution**

Perform the following steps:

* Verify whether the JSON content is valid in the following files:

	* `/home/vsa-installer/pyVins/etc/vsa/vsa_config.json`

	* `/etc/vsa/vsa_network_config.json`

<br><hr>
###Creation of storage pool failed {#storage-pool-fail}

**Probable Cause**

Virtual storage pool will be created for placing the extracted VSA VM image. The storage pool will be created based on local directory  on `/mnt/state/vsa-kvm-storage`

**Resolution**

Perform the following steps:

* Check whether `/mnt/state/vsa-kvm-storage` directory is available.

* Verify for available space to create storage pool in the system.

* Check the libvirt logs for more errors

Refer `/var/log/libvirt/libvirt.log` on VSA system.
 
<br><hr>

###Failed during post VSA deployment {#post-vsa-fail}

**Probable Cause**

The script will persist required files in `/mnt/state/vsa` which will be used for recreating the VSA VM during re-imaging scenario

**Resolution**

This error will occur if the script fails to find `network_vsa.xml`, `storagepool_vsa.xml` and other configuration files which has to be preserved.

* Check for the configuration files on &rdquo;/” path.

* On success, the script updates the `/mnt/state/vsa/vsa_config.json` file with the updated and created time.

<br><hr>

###VSA installation failed {#vsa-install-fail}

**Probable Cause**

When VSA installation fails for any of the above reasons, the script will rollback the network and storage pool.

**Resolution**

Verify the `/installer.log`

<br><hr>


###vsa&#95;network cannot be destroyed {#vsa-network}

**Probable Cause**

VSA network will be destroyed when the VSA installation fails.

**Resolution**

Perform the following steps:

* Check whether the network is already undefined

* Check whether the network name in `<PYVINS_DIRS>/etc/vsa/vsa_config.json` is the same as in the output of `virsh net-list –all` command

<br><hr>

### vsa&#95;storage&#95;pool pool cannot be destroyed {#vsa-pool-cannot-destroy}

**Probable Cause**

The storage pool will be destroyed when VSA installation fails

**Resolution**

Perform the following:

* Verify whether the storage pool is already undefined

* Verify whether the pool name is same as in `<PYVINS_DIRS>/etc/vsa/vsa_config.json`

* Virsh command to list the pools

        Virsh pool-list --all

<br><hr>

##Logging  {#logging}

####Issue in Logging {#issue-in-logging}

The user needs to manually follow the below steps to re-configure Kibana for logging.

1. Log in to Undercloud and start screen session.
2. In the screen, start following command `sudo -u logstash /usr/bin/java -Xmx1g -Djava.io.tmpdir=/var/lib/logstash/ -jar /opt/logstash/logstash.jar agent -f /etc/logstash/conf.d -w 10 --log /var/log/logstash/logstash.log`
3. Press Control **&** '**a**', then '**c**' to create another shell.
4. In a new shell execute command `sudo -u logstash /usr/bin/java -Xmx1g -Djava.io.tmpdir=/var/lib/logstash/ -jar /opt/logstash/logstash.jar agent -f /etc/logstash/conf.d -w 10 --log /var/log/logstash/logstash.log`
5. Repeat steps from **3-4** two times
6. Press Control **&** '**a**' then '**d**' to detach.
 
**Note**: If node reboots repeat the step from **1-6**.

**EDIT**: Added `sudo -u logstash` at beginning of commands. 


<a href="#top" style="padding:14px 0px 14px 0px; text-decoration: none;"> Return to Top &#8593;</a>








----
####OpenStack trademark attribution
*The OpenStack Word Mark and OpenStack Logo are either registered trademarks/service marks or trademarks/service marks of the OpenStack Foundation, in the United States and other countries and are used with the OpenStack Foundation's permission. We are not affiliated with, endorsed or sponsored by the OpenStack Foundation, or the OpenStack community.*
